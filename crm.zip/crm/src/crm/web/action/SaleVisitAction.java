package crm.web.action;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.criterion.DetachedCriteria;


import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.entry.Customer;
import crm.entry.Linkman;
import crm.entry.PageModel;
import crm.entry.SaleVisit;
import crm.entry.User;
import crm.service.CustomerService;
import crm.service.SaleVisitService;
import crm.service.UserService;

public class SaleVisitAction extends ActionSupport implements ModelDriven<SaleVisit> {

	private SaleVisit saleVisit = new SaleVisit();
	@Override
	public SaleVisit getModel() {
		return saleVisit;
	}
	@Resource(name="saleVisitService")
	private SaleVisitService saleVisitService;
	@Resource(name="customerService")
	private CustomerService customerService;
	@Resource(name="userService")
	private UserService userService;
	private Integer currPage = 1;
	private Integer pageSize = 3;
	
	
	public void setCurrPage(Integer currPage) {
		if(currPage == null) {
			currPage = 1;
		}
		this.currPage = currPage;
	}


	public void setPageSize(Integer pageSize) {
		if(pageSize == null) {
			pageSize = 3;
		}
		this.pageSize = pageSize;
	}
	
	
	
	
	
	public String add() {
		saleVisitService.save(saleVisit);
		
		
		return "addSuccess";
		
	}
	
	public String delete() {
		SaleVisit saleVisit1  = saleVisitService.findById(saleVisit.getVisit_id());
		if(saleVisit1 != null) {
			saleVisitService.delete(saleVisit1);
		}
		
		return "deleteSuccess";
	}

	public String goToEdit() {
		
		List<Customer> list1 = customerService.findCustomer();
		ActionContext.getContext().getValueStack().set("list1", list1);
		List<User> list2 = userService.findUser();
		ActionContext.getContext().getValueStack().set("list2", list2);
		SaleVisit saleVisit1 = saleVisitService.findById(saleVisit.getVisit_id());
		ActionContext.getContext().getValueStack().push(saleVisit1);
		
		return "goEdit";
	}
	
	public String Edit() {
		SaleVisit saleVisit1= saleVisitService.findById(saleVisit.getVisit_id());
		saleVisitService.update(saleVisit1);
		return "editSuccess";
	}
	
	public String findAll() {
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(SaleVisit.class);
		
		PageModel<SaleVisit> pageModel =  saleVisitService.findAll(detachedCriteria,currPage,pageSize);
		
		 ActionContext.getContext().getValueStack().push(pageModel);
		return "findAll";
	}
	
	public String addUI() {
		List<Customer> list1 = customerService.findCustomer();
		ActionContext.getContext().getValueStack().set("list1", list1);
		List<User> list2 = userService.findUser();
		ActionContext.getContext().getValueStack().set("list2", list2);
		
		return "addUI";
	}
}
