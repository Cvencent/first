package crm.web.action;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.entry.Customer;
import crm.entry.Linkman;
import crm.entry.PageModel;
import crm.service.CustomerService;
import crm.service.LinkmanService;

public class LinkmanAction extends ActionSupport implements ModelDriven<Linkman>{

	private Linkman linkman = new Linkman();
	@Override
	public Linkman getModel() {
		
		return linkman;
	}

	private LinkmanService linkmanService;
	
	public void setLinkmanService(LinkmanService linkmanService) {
		this.linkmanService= linkmanService;
		
	}
	
	private Integer currPage = 1;
	private Integer pageSize = 3;
	
	
	public void setCurrPage(Integer currPage) {
		if(currPage == null) {
			currPage = 1;
		}
		this.currPage = currPage;
	}


	public void setPageSize(Integer pageSize) {
		if(pageSize == null) {
			pageSize = 3;
		}
		this.pageSize = pageSize;
	}


	private CustomerService customerService;
	
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}


	/*
	 * ��ʾ��ϵ��
	 */
	public String findAll() {
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Linkman.class);
		 if (linkman.getLkm_name() != null &&!"".equals(linkman.getLkm_name())) {
	    	 detachedCriteria.add(Restrictions.like("lkm_name", "%"+linkman.getLkm_name()+"%"));
	    	 }
		PageModel<Linkman> pageModel =  linkmanService.findAll(detachedCriteria,currPage,pageSize);
		
		 ActionContext.getContext().getValueStack().push(pageModel);
		return "findAll";
	} 
	
	/*
	 * ���޸Ľ��������ϵ��
	 */
	public String goToEdit() {
		
		List<Customer> list1 = customerService.findCustomer();
		ActionContext.getContext().getValueStack().set("list1", list1);
		Linkman linkman1 = linkmanService.findById(linkman.getLkm_id());
		
		ActionContext.getContext().getValueStack().push(linkman1);
		return "goEdit";
	}
	/*
	 * �޸���ϵ��
	 */
	public String edit() {
		
		linkmanService.update(linkman);
		
		return "editSuccess";
	}
	/*
	 * ɾ����ϵ��
	 */
	public String delete() {
		
		Linkman linkman1 = linkmanService.findById(linkman.getLkm_id());
		if(linkman1 !=null) {
			linkmanService.delete(linkman1);
		}
		
		return "deleteSuccess";
	}
	
	
	public String addUI() {
		List<Customer> list1 = customerService.findCustomer();
		ActionContext.getContext().getValueStack().set("list1", list1);
		
		return "addUI";
	}
	/*
	 * ������ϵ��s
	 */
	public String add() {
		linkmanService.save(linkman);
		
		return "addSuccess";
	}
}
