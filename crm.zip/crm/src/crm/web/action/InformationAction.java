package crm.web.action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.entry.User;

public class InformationAction extends ActionSupport implements
ModelDriven<User>{
    private User user = new User();
	@Override
	public User getModel() {
		return user;
	}

}
