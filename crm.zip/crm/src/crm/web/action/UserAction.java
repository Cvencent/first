package crm.web.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.entry.User;
import crm.service.UserService;

public class UserAction extends ActionSupport implements ModelDriven<User>{

	private User user = new User();
	@Override
	public User getModel() {
		
		return user;
	}
	private UserService userService;
	
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}


	public String regist() {
		userService.regist(user);
		
		return LOGIN;
	}
	
	/*
	 * �û���¼
	 */
	public String login() {
		
		User isexist = userService.login(user);
		if (isexist == null) {
			//��¼ʧ��
			this.addActionError("�û������������");
			return LOGIN;
		}else {
			//��¼�ɹ�
			ServletActionContext.getRequest().getSession().setAttribute("isexist", isexist);
			return SUCCESS;
		}
	}

}
