package crm.web.action;



import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.entry.BaseDict;
import crm.entry.Customer;
import crm.entry.PageModel;
import crm.service.CustomerService;
import crm.utils.UploadUtil;

public class CustomerAction extends ActionSupport implements ModelDriven<Customer> {

	private Customer customer = new Customer();
	@Override
	public Customer getModel() {
		
		return customer;
	}
	
	private CustomerService customerService;
	
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

	
	private Integer CurrPage = 1;
	
	
	public void setCurrPage(Integer currPage) {
	     if (currPage == null) {
	    	 currPage=1;
	     }
		
		CurrPage = currPage;
	}

	private Integer PageSize = 3;
	
	
	public void setPageSize(Integer pageSize) {
		
		if(pageSize == null) {
			pageSize = 3;
		}
		PageSize = pageSize;
	}

	/*
	 * �ͻ�����������ҳ��ķ���
	 */
	public String saveUI(){
	
		return "saveUI";
	}
	private String uploadFileName;
	private File upload;
	private String uploadContentType;
	
	
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}


	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	/*
	 * ����ͻ��ķ���
	 */
     public String save() throws IOException {
    	 if(upload != null) {
    		 //�ļ��ϴ�·��
    		 String path = "E:/source";
    		
    		 //�õ�����ļ���
    		 String uuidFileName = UploadUtil.uploadUuidFileName(uploadFileName);
    		 
    		 //�õ��洢·��
    		 String realPath = UploadUtil.uploadPath(uuidFileName);
    		 String url = path + realPath;
    		 //����Ŀ¼
    		 File dictory = new File(url);
    		 if(!dictory.exists()) {
    			 dictory.mkdir();
    		 }
    		 
    		 //�ϴ��ļ�
    		 File uploadFile = new File(url+"/"+uuidFileName);
    		 FileUtils.copyFile(upload, uploadFile);
    		 customer.setCust_image(url+"/"+uuidFileName);
    	 }
    
    	 customerService.save(customer);
    	 return "saveSuccess";
     }
     /*
               *         ��ҳ��ѯ�ķ���
      */
     public String findAll() {
    	 //���߲�ѯ
    	 DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Customer.class);
    
    	 if (customer.getCust_name() != null &&!"".equals(customer.getCust_name())) {
    	 detachedCriteria.add(Restrictions.like("cust_name", "%"+customer.getCust_name()+"%"));
    	 }
    	 if(customer.getBaseSource()!=null) {
    		 if(customer.getBaseSource().getDict_id()!=null && !"".equals(customer.getBaseSource().getDict_id())) {
    			 detachedCriteria.add(Restrictions.eq("baseSource.dict_id", customer.getBaseSource().getDict_id()));
    		 } 
    	 }
    	 
    	 if(customer.getBaseLevel()!=null) {
    		 if(customer.getBaseLevel().getDict_id()!=null&& !"".equals(customer.getBaseLevel().getDict_id())) {
    			 detachedCriteria.add(Restrictions.eq("baseLevel.dict_id", customer.getBaseLevel().getDict_id()));
    		 } 
    	 }
    	 
    	 if(customer.getBaseIndustry()!=null) {
    		 if(customer.getBaseIndustry().getDict_id()!=null&& !"".equals(customer.getBaseIndustry().getDict_id())) {
    			 detachedCriteria.add(Restrictions.eq("baseIndustry.dict_id", customer.getBaseIndustry().getDict_id()));
    		 } 
    	 }
    	 
    	 PageModel<Customer> pageModel = customerService.findByPage(detachedCriteria,CurrPage,PageSize);
    	 
    	 ActionContext.getContext().getValueStack().push(pageModel);
    	 return "findAll";
     }
     
   

	/*
      *   ͨ��idɾ���ͻ��ķ���
      */
     public String deleteById() {
    	 
    	 Customer customer1 = customerService.deleteById(customer.getCust_id());
    	 if(customer1 !=null) {
    		 String url = customer1.getCust_image();
    		 if(url!=null) {
    			 File file = new File(url);
    			 if(file.exists()) {
    				 file.delete();
    			 }		 
    		 }		 
    	 }
    	 return "deleteSuccess";
     }
     
     public String goToEdit() {
    	 Customer customer1 =customerService.findById(customer.getCust_id());
    	 ActionContext.getContext().getValueStack().push(customer1);
    	 return "gotoEdit";
    	 
    	 
    	 
     }
     public String edit() {
    	
    	
    	customerService.update(customer); 
    	 
    	 return "editSuccess";
     }
}
