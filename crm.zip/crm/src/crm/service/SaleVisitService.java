package crm.service;

import org.hibernate.criterion.DetachedCriteria;

import crm.entry.PageModel;
import crm.entry.SaleVisit;

public interface SaleVisitService {

	PageModel<SaleVisit> findAll(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize);

	SaleVisit findById(String visit_id);

	void save(SaleVisit saleVisit);

	void update(SaleVisit saleVisit);

	void delete(SaleVisit saleVisit);

}
