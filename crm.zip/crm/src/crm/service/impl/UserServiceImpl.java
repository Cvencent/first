package crm.service.impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import crm.dao.UserDao;
import crm.entry.User;
import crm.service.UserService;
import crm.utils.MD5Utils;

@Transactional
public class UserServiceImpl implements UserService {

	private UserDao userDao;
	
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}


	@Override
	public void regist(User user) {
		user.setUser_password(MD5Utils.md5(user.getUser_password()));
		user.setUser_state("1");
		userDao.save(user);
		
	}


	/*
	 * �û���¼
	 */
	@Override
	public User login(User user) {
		user.setUser_password(MD5Utils.md5(user.getUser_password()));
		
		
		
		return userDao.login(user);
	}


	@Override
	public List<User> findUser() {
		
		return userDao.findUser();
	}

}
