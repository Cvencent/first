package crm.service.impl;



import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.transaction.annotation.Transactional;

import crm.dao.CustomerDao;
import crm.entry.Customer;
import crm.entry.PageModel;
import crm.service.CustomerService;

@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	private CustomerDao customerDao;

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}

	@Override
	public void save(Customer customer) {
		customerDao.save(customer);
		
	}

	@Override
	public PageModel<Customer> findByPage(DetachedCriteria detachedCriteria, Integer currPage,Integer pageSize) {
		PageModel<Customer> pageModel = new PageModel<Customer>();
		
		pageModel.setCurrPage(currPage);
		pageModel.setPageSize(pageSize);
		
		Integer totalCount = customerDao.findCount(detachedCriteria);
		Integer count = totalCount/pageSize;
		Integer num =  (totalCount%pageSize>0)?(count+1):count;
		pageModel.setTotalPage(num);
		Integer begin= (currPage -1)*pageSize;
	
		pageModel.setTotalCount(totalCount);
		 List<Customer> list= customerDao.findByPage(detachedCriteria,begin,pageSize);
		 
		 pageModel.setList(list);
		return pageModel;
	}

	@Override
	public Customer deleteById(Long cust_id) {
		return customerDao.deleteById(cust_id);
		
	}

	@Override
	public Customer findById(Long cust_id) {
		
		return customerDao.findById(cust_id);
	}

	@Override
	public void update(Customer customer) {
		customerDao.update(customer);
		
	}

	@Override
	public List<Customer> findCustomer() {
		
		return customerDao.findCustomer();
	}
	

}
