package crm.service.impl;



import java.util.List;

import javax.annotation.Resource;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.transaction.annotation.Transactional;

import crm.dao.SaleVisitDao;

import crm.entry.PageModel;
import crm.entry.SaleVisit;
import crm.service.SaleVisitService;
@Transactional
public class SaleVisitServiceImpl implements SaleVisitService {

	@Resource(name="saleVisitDao")
	private SaleVisitDao saleVisitDao;

	@Override
	public PageModel<SaleVisit> findAll(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize) {
		   PageModel<SaleVisit> pageModel = new PageModel<SaleVisit>();
			
			pageModel.setCurrPage(currPage);
			pageModel.setPageSize(pageSize);
			//��ѯ�ܼ�¼��
			Integer totalCount = saleVisitDao.findCount(detachedCriteria);
			//����ҳ��
			Integer count = totalCount/pageSize;
			Integer num =  (totalCount%pageSize>0)?(count+1):count;
			
			pageModel.setTotalPage(num);
			//�����ҳ��ʼλ��
			Integer begin= (currPage -1)*pageSize;
		
			pageModel.setTotalCount(totalCount);
			 List<SaleVisit> list= saleVisitDao.findByPage(detachedCriteria,begin,pageSize);
			 
			 pageModel.setList(list);
			return pageModel;
	}

	@Override
	public SaleVisit findById(String visit_id) {
		
		
		return saleVisitDao.findById(visit_id);
	}

	@Override
	public void save(SaleVisit saleVisit) {
		saleVisitDao.save(saleVisit);
		
	}

	@Override
	public void update(SaleVisit saleVisit) {
		saleVisitDao.update(saleVisit);
		
	}

	@Override
	public void delete(SaleVisit saleVisit) {
		saleVisitDao.delete(saleVisit);
		
	}

	
	
	
}
