package crm.service.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.transaction.annotation.Transactional;

import crm.dao.LinkmanDao;
import crm.entry.Customer;
import crm.entry.Linkman;
import crm.entry.PageModel;
import crm.service.LinkmanService;

@Transactional
public class LinkmanServiceImpl implements LinkmanService {
	
	private LinkmanDao linkmanDao;

	public void setLinkmanDao(LinkmanDao linkmanDao) {
		this.linkmanDao = linkmanDao;
	}

	@Override
	public PageModel<Linkman> findAll(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize) {
         PageModel<Linkman> pageModel = new PageModel<Linkman>();
		
		pageModel.setCurrPage(currPage);
		pageModel.setPageSize(pageSize);
		//��ѯ�ܼ�¼��
		Integer totalCount = linkmanDao.findCount(detachedCriteria);
		//����ҳ��
		Integer count = totalCount/pageSize;
		Integer num =  (totalCount%pageSize>0)?(count+1):count;
		
		pageModel.setTotalPage(num);
		//�����ҳ��ʼλ��
		Integer begin= (currPage -1)*pageSize;
	
		pageModel.setTotalCount(totalCount);
		 List<Linkman> list= linkmanDao.findByPage(detachedCriteria,begin,pageSize);
		 
		 pageModel.setList(list);
		return pageModel;
	}

	@Override
	public void save(Linkman linkman) {
		linkmanDao.save(linkman);
		
	}

	@Override
	public Linkman findById(Long lkm_id) {
		
		return linkmanDao.findById(lkm_id);
	}

	@Override
	public void update(Linkman linkman1) {
		linkmanDao.update(linkman1);
		
	}

	@Override
	public void delete(Linkman linkman1) {
		linkmanDao.delete(linkman1);
		
	}

	
	

}
