package crm.service;



import org.hibernate.criterion.DetachedCriteria;


import crm.entry.Linkman;
import crm.entry.PageModel;

public interface LinkmanService {

	PageModel<Linkman> findAll(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize);

	void save(Linkman linkman);

	Linkman findById(Long lkm_id);

	void update(Linkman linkman1);

	void delete(Linkman linkman1);

	

}
