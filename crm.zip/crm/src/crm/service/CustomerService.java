package crm.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.entry.Customer;
import crm.entry.PageModel;


public interface CustomerService {

	/*
	 * ����ͻ�
	 */
	void save(Customer customer);

	/*
	 * ��ҳ��ѯ
	 */
	PageModel<Customer> findByPage(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize);

	Customer deleteById(Long cust_id);

	Customer findById(Long cust_id);

	void update(Customer customer);

	List<Customer> findCustomer();

}
