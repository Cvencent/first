package crm.service;

import java.util.List;

import crm.entry.User;

public interface UserService {

	/*
	 * �û�ע��
	 */
	void regist(User user);

	/*
	 * ��¼У��
	 */
	User login(User user);

	List<User> findUser();

}
