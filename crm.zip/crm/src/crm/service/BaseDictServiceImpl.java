package crm.service;

import java.util.List;

import crm.dao.BaseDictDao;
import crm.entry.BaseDict;



public class BaseDictServiceImpl implements BaseDictService {

	private BaseDictDao baseDictDao;

	public void setBaseDictDao(BaseDictDao baseDictDao) {
		this.baseDictDao = baseDictDao;
	}

	@Override
	public List<BaseDict> findTypeCode(String dict_type_code) {
		
		return baseDictDao.findByTypeCode(dict_type_code);
	}
	
}
