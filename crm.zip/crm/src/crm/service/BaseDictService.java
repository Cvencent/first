package crm.service;

import java.util.List;

import crm.entry.BaseDict;


public interface BaseDictService {

	List<BaseDict> findTypeCode(String dict_type_code);

}
