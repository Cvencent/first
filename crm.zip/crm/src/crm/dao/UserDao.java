package crm.dao;

import java.util.List;

import crm.entry.User;

public interface UserDao {

	void save(User user);

	User login(User user);

	List<User> findUser();

}
