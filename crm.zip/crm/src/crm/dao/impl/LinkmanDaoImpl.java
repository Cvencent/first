package crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.LinkmanDao;
import crm.entry.Customer;
import crm.entry.Linkman;

public class LinkmanDaoImpl extends HibernateDaoSupport implements LinkmanDao {

	@Override
	public Integer findCount(DetachedCriteria detachedCriteria) {
		detachedCriteria.setProjection(Projections.rowCount());
		@SuppressWarnings("unchecked")
		List<Long> list= (List<Long>) this.getHibernateTemplate().findByCriteria(detachedCriteria);
		 
		 if(!list.isEmpty()) {
			 return list.get(0).intValue();
		 }
		return null;
	}

	@Override
	public List<Linkman> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize) {
		detachedCriteria.setProjection(null);
		
		@SuppressWarnings("unchecked")
		List<Linkman> list =  (List<Linkman>) this.getHibernateTemplate().findByCriteria(detachedCriteria, begin, pageSize);
		return list;
	}

	@Override
	public void save(Linkman linkman) {
		this.getHibernateTemplate().save(linkman);
		
	}

	@Override
	public Linkman findById(Long lkm_id) {

		@SuppressWarnings("unchecked")
		List<Linkman> list =  (List<Linkman>) this.getHibernateTemplate().find("from Linkman where lkm_id = ?",lkm_id);
		
		if(!list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public void update(Linkman linkman1) {
		
		this.getHibernateTemplate().update(linkman1);
		
	}

	@Override
	public void delete(Linkman linkman1) {
		this.getHibernateTemplate().delete(linkman1);
		
	}

	
}
