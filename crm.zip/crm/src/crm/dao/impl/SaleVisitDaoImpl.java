package crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.SaleVisitDao;
import crm.entry.Linkman;
import crm.entry.SaleVisit;

public class SaleVisitDaoImpl extends HibernateDaoSupport implements SaleVisitDao {

	@Override
	public Integer findCount(DetachedCriteria detachedCriteria) {
		detachedCriteria.setProjection(Projections.rowCount());
		@SuppressWarnings("unchecked")
		List<Long> list= (List<Long>) this.getHibernateTemplate().findByCriteria(detachedCriteria);
		 
		 if(!list.isEmpty()) {
			 return list.get(0).intValue();
		 }
		return null;
	}

	@Override
	public List<SaleVisit> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize) {
        detachedCriteria.setProjection(null);
		
		@SuppressWarnings("unchecked")
		List<SaleVisit> list =  (List<SaleVisit>) this.getHibernateTemplate().findByCriteria(detachedCriteria, begin, pageSize);
		return list;             
	}

	@Override
	public SaleVisit findById(String visit_id) {
		List<SaleVisit> list=(List<SaleVisit>) this.getHibernateTemplate().find("from SaleVisit where visit_id = ?", visit_id);
		if(!list.isEmpty()) {
			return list.get(0);
		}
		
		return  null;
	}

	@Override
	public void save(SaleVisit saleVisit) {
		this.getHibernateTemplate().save(saleVisit);
		
	}

	@Override
	public void update(SaleVisit saleVisit) {
		this.getHibernateTemplate().update(saleVisit);
	}

	@Override
	public void delete(SaleVisit saleVisit) {
	    this.getHibernateTemplate().delete(saleVisit);
		
	}

	

}
