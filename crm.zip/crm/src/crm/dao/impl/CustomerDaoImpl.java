package crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.CustomerDao;
import crm.entry.Customer;

public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

	@Override
	public void save(Customer customer) {
		this.getHibernateTemplate().save(customer);
	}

	@Override
	public List<Customer> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize) {
		detachedCriteria.setProjection(null);
		@SuppressWarnings("unchecked")
		List<Customer> list= (List<Customer>) this.getHibernateTemplate().findByCriteria(detachedCriteria,begin, pageSize);
		return list;
	}

	
	@Override
	public Integer findCount(DetachedCriteria detachedCriteria) {
		detachedCriteria.setProjection(Projections.rowCount());
		 @SuppressWarnings("unchecked")
		List<Long> list= (List<Long>) this.getHibernateTemplate().findByCriteria(detachedCriteria);
		 
		 if(!list.isEmpty()) {
			 return list.get(0).intValue();
		 }
		return null;
	}

	@Override
	public Customer deleteById(Long cust_id) {
		
		@SuppressWarnings("unchecked")
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer where cust_id = ?", cust_id);
		if(!list.isEmpty()) {
			this.getHibernateTemplate().delete(list.get(0));
			return list.get(0);
			}
		return null;
		
	}

	@Override
	public Customer findById(Long cust_id) {
		@SuppressWarnings("unchecked")
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer where cust_id = ?", cust_id);
		if(!list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public void update(Customer customer) {
		this.getHibernateTemplate().update(customer);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findCustomer() {
		
		return (List<Customer>) this.getHibernateTemplate().find("from Customer");
	}

}
