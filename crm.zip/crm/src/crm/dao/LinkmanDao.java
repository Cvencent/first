package crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.entry.Customer;
import crm.entry.Linkman;

public interface LinkmanDao {

	Integer findCount(DetachedCriteria detachedCriteria);

	List<Linkman> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);

	void save(Linkman linkman);

	Linkman findById(Long lkm_id);

	void update(Linkman linkman1);

	void delete(Linkman linkman1);

	

}
