package crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.entry.Customer;

public interface CustomerDao {

	void save(Customer customer);

	

	List<Customer> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);



	 Integer findCount(DetachedCriteria detachedCriteria);



	Customer deleteById(Long cust_id);



	Customer findById(Long cust_id);



	void update(Customer customer);



	List<Customer> findCustomer();

}
