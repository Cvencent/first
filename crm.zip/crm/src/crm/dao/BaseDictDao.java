package crm.dao;

import java.util.List;

import crm.entry.BaseDict;

public interface BaseDictDao {

	List<BaseDict> findByTypeCode(String dict_type_code);

}
