package crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.entry.SaleVisit;

public interface SaleVisitDao {

	Integer findCount(DetachedCriteria detachedCriteria);

	List<SaleVisit> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);

	SaleVisit findById(String visit_id);

	void save(SaleVisit saleVisit);

	void update(SaleVisit saleVisit);

	void delete(SaleVisit saleVisit);

}
