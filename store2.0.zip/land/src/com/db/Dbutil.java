package com.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbutil {
	private final static String URL = "jdbc:mysql://127.0.0.1:3306/mall";
	private final static String ROOT = "root";
	private final static String PASSWORD = "123456";
	private static Connection con = null;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(URL, ROOT, PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Connection get() {
		return con;
	}
}
