package com.os;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.db.Dbutil;
import com.o.User;


public class UserDao {
	int a = 0;
	public int land(User r) throws SQLException {
		Dbutil db = new Dbutil();
		String sql = " SELECT * FROM admin WHERE user = ?";
		PreparedStatement st = db.get().prepareStatement(sql);
		st.setString(1, r.getName());
		ResultSet rs = st.executeQuery();
		if(!rs.next()) {
			String sql1 = " SELECT * FROM user WHERE user = ?";
			PreparedStatement st1 = db.get().prepareStatement(sql1);
			st1.setString(1, r.getName());
			ResultSet rs1 = st1.executeQuery();
			if(rs1.next()) {
				if (r.getPassword().equals(rs1.getString("password"))) {
					a= 2;
				}
			}
		}
		else{
			if (r.getPassword().equals(rs.getString("password"))) {
				a= 1;
			}
	    }
		return a;
	}
	public void add(User r) throws SQLException {
		Dbutil db = new Dbutil();
		String sql = " INSERT INTO user(user,password) VALUES(?,?)";
		PreparedStatement ps = db.get().prepareStatement(sql);
		ps.setString(1,r.getName());
		ps.setString(2, r.getPassword());
		ps.execute();
	}
}