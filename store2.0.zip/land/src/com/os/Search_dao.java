package com.os;

public class Search_dao { 
	 private String content = "";

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	 

}
