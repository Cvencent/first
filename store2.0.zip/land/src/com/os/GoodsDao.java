package com.os;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.db.Dbutil;
import com.o.Goods;

public class GoodsDao {
 
 public void del(String a) throws SQLException {
		 Dbutil db = new Dbutil();
		 String sql = " DELETE FROM goods WHERE name = ?";
		 PreparedStatement ps=  db.get().prepareStatement(sql);
		 ps.setString(1, a);
		 ps.execute();
} 
 
 public List<Goods> all(String a) throws SQLException {
	 Dbutil db = new Dbutil();
	 List<Goods> list= new ArrayList<>();
	 String sql = ""
		 		+ " SELECT * FROM "+a;
	 PreparedStatement ps=  db.get().prepareStatement(sql);
	 ResultSet rs = ps.executeQuery();
	 while(rs.next()) {
		 Goods g1 = new Goods();
		g1.setFee(rs.getString("fee"));
		g1.setName(rs.getString("name"));
		g1.setPrice(rs.getString("price"));
		g1.setNick(rs.getString("nick"));
		g1.setComment(rs.getString("comment"));
		g1.setCity(rs.getString("city"));
		g1.setSales(rs.getString("sales"));
		g1.setImg(rs.getString("img"));
		list.add(g1);
	 }
	 return list;
 }
}