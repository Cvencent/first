package com.os;

import java.sql.SQLException;
import java.util.List;

import com.o.Goods;

public class Test {

	public static void main(String[] args) throws SQLException {
		GoodsDao gs = new GoodsDao();
		String a ="women_wear";
	 List<Goods> l =gs.all(a);
	 for(Goods g :l) {
		 System.out.println(g.toString());
	 }

	}

}
