package com.os;

import java.sql.SQLException;

public class dsaeasd {

	public static void main(String[] args) throws SQLException {
		Shopping_car_dao a = new Shopping_car_dao();
		a.create("aaa");
       
	}

}
