package com.os;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.db.Dbutil;
import com.o.Goods;

public class Shopping_car_dao {
     public void add(String a,String img,String name,String price,String fee,String city,String nick) throws SQLException {
    	 Dbutil db = new Dbutil();
    	 a= "shopping_car_"+a;
    	 String sql =""
    	 		+ "INSERT INTO "+a+" (img,name,price,fee,city,nick)"
    	 		+ "VALUES(?,?,?,?,?,?)";
    	 PreparedStatement ps=db.get().prepareStatement(sql);
    	 ps.setString(1, img);
    	 ps.setString(2, name);
    	 ps.setString(3, price);
    	 ps.setString(4, fee);
    	 ps.setString(5, city);
    	 ps.setString(6, nick);
    	 ps.execute();
    	 
     }
     public List<Goods> all(String a) throws SQLException {
    	 Dbutil db = new Dbutil();
    	 List<Goods> list= new ArrayList<>();
    	 String sql = ""
    		 		+ " SELECT * FROM shopping_car_"+a;
    	 PreparedStatement ps=  db.get().prepareStatement(sql);
    	 ResultSet rs = ps.executeQuery();
    	 while(rs.next()) {
    		 Goods g1 = new Goods();
    		g1.setFee(rs.getString("fee"));
    		g1.setName(rs.getString("name"));
    		g1.setPrice(rs.getString("price"));
    		g1.setNick(rs.getString("nick"));
    		g1.setCity(rs.getString("city"));
    		g1.setImg(rs.getString("img"));
    		list.add(g1);
    	 }
    	 return list;
     }
     
     public void create(String a) throws SQLException {
    	 Dbutil db = new Dbutil();
    	 a= "shopping_car_"+a;
    	 String sql = "  CREATE TABLE " +a+
    	 		" ( name VARCHAR(200), " + 
    	 		"  price VARCHAR(20), " + 
    	 		"  fee VARCHAR(10), " + 
    	 		"  city VARCHAR(10),"
    	 		+ "nick VARCHAR(100), " + 
    	 		"  img VARCHAR(1000) " + 
    	 		"); ";
    	 PreparedStatement ps= db.get().prepareStatement(sql);
    	 ps.execute();
     }
     public int inquir(String a) throws SQLException {
    	 Dbutil db = new Dbutil();
    	 int num = 0;
    	 a= "shopping_car_"+a;
    	 String sql = "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_NAME= \""+a+"\"; ";
    	 PreparedStatement ps= db.get().prepareStatement(sql);
    	 ResultSet rs = ps.executeQuery();
    	 while(rs.next()) {
    		num = rs.getInt("COUNT(*)");
    	 }
    	 return num;
     }
     
}
