package com.shop.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dbutil {
	private final static String URL = "jdbc:mysql://127.0.0.1:3306/mall";
	private final static String USER = "root";
	private final static String PASSWORD = "123456";
	private static Connection con = null;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}   
		try {
			con = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public Connection get() throws SQLException {
		return con;
		
	}

}
