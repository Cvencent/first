package com.shop.model;

public class Goods {
	@Override
	public String toString() {
		return id + "\t" + name + "\t" + type + "\t" + brand + "\t" + price
				+ "\t" + stock + "\t" + sell + "\t";
	}

	private Integer id = null;
	private String name = null;
	private String type = null;
	private String brand = null;
	private double price;
	private Integer stock = null;
	private Integer sell = null;
	private Integer grounding = null;;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public Integer getSell() {
		return sell;
	}

	public void setSell(Integer sell) {
		this.sell = sell;
	}

	public Integer getGrounding() {
		return grounding;
	}

	public void setGrounding(Integer grounding) {
		this.grounding = grounding;
	}
}
