package com.shop.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shop.db.Dbutil;
import com.shop.model.Goods;

public class Goodsdao {
 public void add(Goods g) throws SQLException {
	 Dbutil db = new Dbutil();
	 
	 String sql = ""
	 		+ " INSERT INTO goods(name,type,brand,price,stock,grounding)"
	 		+ " VALUES("
	 		+ " ?,?,?,?,?,?)";
	PreparedStatement ps=  db.get().prepareStatement(sql);
	ps.setString(1, g.getName());
	ps.setString(2, g.getType());
	ps.setString(3, g.getBrand());
	ps.setDouble(4, g.getPrice());
	ps.setInt(5, g.getStock());
	ps.setInt(6, g.getGrounding());
	ps.execute();
	 
 }
 public void del(int a) throws SQLException {
		 Dbutil db = new Dbutil();
		 String sql = " DELETE FROM goods WHERE id = ?";
		 PreparedStatement ps=  db.get().prepareStatement(sql);
		 ps.setInt(1, a);
		 ps.execute();
} 
 public void update(int a,Goods g) throws SQLException {
	 Dbutil db = new Dbutil();
 
 String sql = ""
 		+ " UPDATE goods SET name = ?, type = ?,"
 		+ "  brand = ?, price = ?, stock = ?,"
 		+ "  grounding = ? WHERE id = ?";
  	 PreparedStatement ps=  db.get().prepareStatement(sql);
	 ps.setString(1, g.getName());
	 ps.setString(2, g.getType());
	 ps.setString(3, g.getBrand());
	 ps.setDouble(4, g.getPrice());
	 ps.setInt(5, g.getStock());
 	 ps.setInt(6, g.getGrounding()); 
	 ps.setInt(7, a);
	 ps.execute();
  }
 public Goods sel(int a) throws SQLException {
	 Dbutil db = new Dbutil();
	 String sql = ""
		 		+ " SELECT * FROM goods WHERE id = ? ";
	 PreparedStatement ps=  db.get().prepareStatement(sql);
	 ps.setObject(1, a);
	 ResultSet rs = ps.executeQuery();
	 Goods g1 = new Goods();
	 while(rs.next()) {
		g1.setId(rs.getInt("id"));
		g1.setName(rs.getString("name"));
		g1.setType(rs.getString("type"));
		g1.setBrand(rs.getString("brand"));
		g1.setPrice(rs.getDouble("price"));
		g1.setStock(rs.getInt("stock"));
		g1.setSell(rs.getInt("sell"));
		g1.setGrounding(rs.getInt("grounding"));
	 }
	 return g1;
 }
 
 public List<Goods> all() throws SQLException {
	 Dbutil db = new Dbutil();
	 List<Goods> list= new ArrayList<>();
	 String sql = ""
		 		+ " SELECT * FROM goods";
	 PreparedStatement ps=  db.get().prepareStatement(sql);
	 ResultSet rs = ps.executeQuery();
	 while(rs.next()) {
		 Goods g1 = new Goods();
		g1.setId(rs.getInt("id"));
		g1.setName(rs.getString("name"));
		g1.setType(rs.getString("type"));
		g1.setBrand(rs.getString("brand"));
		g1.setPrice(rs.getDouble("price"));
		g1.setStock(rs.getInt("stock"));
		g1.setSell(rs.getInt("sell"));
		g1.setGrounding(rs.getInt("grounding"));
		list.add(g1);
	 }
	 return list;
 }
}
