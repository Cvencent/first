package com.shop.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.shop.db.Dbutil;
import com.shop.model.Goods;
import com.shop.model.Shopping_car;

public class Shopping_cardao {
    public void add(Goods g) throws SQLException {
    	Dbutil db = new Dbutil();
    	String sql = " INSERT INTO shopping_car(id,name,price) VALUES(?,?,?)";
    	PreparedStatement ps =  db.get().prepareStatement(sql);
    	ps.setInt(1,g.getId() );
    	ps.setString(2, g.getName());
    	ps.setDouble(3, g.getPrice());
    	ps.execute();
    }
    public void del(int a) throws SQLException {
    	Dbutil db = new Dbutil();
    	String sql = "DELETE FROM shopping_car WHERE id = ?";
    	PreparedStatement ps = db.get().prepareStatement(sql);
    	ps.setInt(1, a);
    	ps.execute();
    }
    
    public List<Shopping_car> all() throws SQLException{
    	 Dbutil db = new Dbutil();
    	 List<Shopping_car> list= new ArrayList<>();
    	 String sql = ""
    		 		+ " SELECT * FROM shopping_car";
    	 PreparedStatement ps=  db.get().prepareStatement(sql);
    	 ResultSet rs = ps.executeQuery();
    	 while(rs.next()) {
    		 Shopping_car g1 = new Shopping_car();
    		g1.setId(rs.getInt("id"));
    		g1.setName(rs.getString("name"));
    		g1.setPrice(rs.getDouble("price"));
    		list.add(g1);
    	 }
    	 return list;
    }
    public double money() throws SQLException {
    	Dbutil db = new Dbutil();
    	double s = 0;
    	String sql = ""
    			+ "SELECT SUM(price) FROM shopping_car";
    	Statement sm = db.get().createStatement();
    	ResultSet rs = sm.executeQuery(sql);
    	while(rs.next()) {
    		s = rs.getDouble("SUM(price)");
    	}
    	return s;
    }
}
