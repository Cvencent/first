package signals;

import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;

import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/*
 * 视图层
 */
public class View extends JFrame {

	static XYSeriesCollection dataset1 = null;
	static XYSeriesCollection dataset2 = null;
	static JFrame frame = new JFrame("频响特性与零极点分布");
	static JFrame frame1 = new JFrame("频响特性与零极点分布");

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {

		Font FONT = new Font("宋体", Font.PLAIN, 20);
		// 设置中文主题样式 解决乱码
		StandardChartTheme chartTheme = new StandardChartTheme("CN");
		// 设置标题字体
		chartTheme.setExtraLargeFont(FONT);
		// 设置图例的字体
		chartTheme.setRegularFont(FONT);
		// 设置轴向的字体
		chartTheme.setLargeFont(FONT);
		chartTheme.setSmallFont(FONT);
		ChartFactory.setChartTheme(chartTheme);
		get(frame);

	}

	private static void components(JPanel panel) {

		JLabel label = new JLabel("H(s)=");
		label.setBounds(0, 110, 130, 15);
		label.setFont(new Font("宋体", Font.BOLD, 20));
		label.setVisible(true);
		panel.add(label);
		JTextField zerotext = new JTextField();
		zerotext.setLocation(100, 90);
		zerotext.setSize(100, 25);
		panel.add(zerotext);
		JTextField k = new JTextField();
		k.setLocation(65, 108);
		k.setSize(25, 25);
		panel.add(k);
		JTextField limittext = new JTextField();
		limittext.setLocation(100, 125);
		limittext.setSize(100, 25);
		panel.add(limittext);

		JButton Button1 = new JButton("分析");
		Button1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Dao dao = new Dao();
				Model model = new Model();
				Model model2 = new Model();

				double ks = Double.parseDouble(k.getText());
				model = dao.split_zero(zerotext.getText());
				model2 = dao.split_limit(limittext.getText());
				ArrayList<Double> zero_point = model.get_zp();
				ArrayList<Double> limit_point = model2.get_l();
				System.out.println(zero_point.size());
				XYSeries series1 = new XYSeries("xySeries");
				XYSeries series2 = new XYSeries("xySeries");
				JLabel label = new JLabel();
				label.setBounds(0, 110, 300, 20);
				label.setFont(new Font("宋体", Font.BOLD, 20));
				label.setVisible(true);
				label.setText(dao.stable(model2));
				JPanel panels = new JPanel();
				panels.setLayout(null);
				panels.setSize(200, 200);
				panels.setLocation(850, 650);
				JLabel label2 = new JLabel();
				label2.setBounds(0, 140, 330, 20);
				label2.setFont(new Font("宋体", Font.BOLD, 20));
				label2.setVisible(true);
				label2.setText(dao.all_pass(model, model2));
				panels.add(label2);
				panels.add(label);

				double y = 0;

				for (double w = 0.0001; w < 15; w = w + 0.01) {
					y = 0;
					for (int i = 0; i < zero_point.size(); i++) {
						if (zero_point.get(i) < 0) {
							y = y + (180 / (Math.PI / Math.atan2(w, Math.abs(zero_point.get(i)))));
						} else {
							y = y + (180 - (180 / (Math.PI / Math.atan2(w, Math.abs(zero_point.get(i))))));
						}
					}

					for (int i = 0; i < limit_point.size(); i++) {
						if (limit_point.get(i) <= 0) {
							y = y - (180 / (Math.PI / Math.atan2(w, Math.abs(limit_point.get(i)))));
						} else {
							y = y - 180 + (180 / (Math.PI / Math.atan2(w, Math.abs(limit_point.get(i)))));
						}
					}

					series1.add(w, y);
				}

				XYSeriesCollection Dataset1 = new XYSeriesCollection();
				Dataset1.addSeries(series1);
				dataset1 = Dataset1;

				for (double w = 0.0001; w < 15; w = w + 0.01) {
					int j = 0;
					boolean p = true;
					if (zero_point.size() < limit_point.size()) {
						j = limit_point.size() - zero_point.size();
					}
					y = ks;
					for (int i = limit_point.size() - 1; i >= 0; i--) {
						p = true;
						if (j > 0) {
							y = y * ((Math.cos(Math.atan(w / Math.abs(limit_point.get(i)))))
									/ Math.abs(limit_point.get(i)));
							j--;
							p = false;
						}

						if (j == 0 && p == true) {
							y = y * (Math.sin(Math.atan(w / Math.abs(limit_point.get(i)))));
						}
					}
					series2.add(w, y);
				}
				XYSeriesCollection Dataset2 = new XYSeriesCollection();
				Dataset2.addSeries(series2);
				dataset2 = Dataset2;

				JFrame frame1 = new JFrame("频响特性与零极点分布");
				frame1.add(panels);
				frame.setVisible(false);
				get(frame1);
				set_frame(frame1);

			}
		});
		JButton Button2 = new JButton("清空");
		Button2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				frame1.setVisible(false);
				frame.setVisible(true);
			}
		});
		JButton Button3 = new JButton("退出");
		Button3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
				frame1.dispatchEvent(new WindowEvent(frame1, WindowEvent.WINDOW_CLOSING));
			}
		});
		Button1.setBounds(30, 380, 80, 25);
		Button2.setBounds(30, 480, 80, 25);
		Button3.setBounds(30, 580, 80, 25);
		panel.add(Button1);
		panel.add(Button2);
		panel.add(Button3);
	}

	private static void get(JFrame frame) {
		frame.setSize(1200, 1000);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new ChartPanel(ChartFactory.createXYLineChart("相频曲线", "w", "φ(w)", dataset1,
				PlotOrientation.VERTICAL, false, false, false));
		JPanel panel2 = new ChartPanel(ChartFactory.createXYLineChart("幅频曲线", "w", "V2/V1", dataset2,
				PlotOrientation.VERTICAL, false, false, false));
		JPanel panel3 = new JPanel();
		panel.setLocation(0, 0);
		panel.setSize(800, 450);
		panel2.setLocation(0, 500);
		panel2.setSize(800, 450);
		panel3.setLocation(820, 0);
		panel3.setSize(350, 600);
		components(panel3);
		frame.add(panel);
		frame.add(panel2);
		panel3.setLayout(null);
		frame.add(panel3);

		frame.setVisible(true);
	}

	public static void set_frame(JFrame f) {
		frame1 = f;
	}

}
