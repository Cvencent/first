package signals;

import java.util.ArrayList;

/*
 * 模型层
 */
public class Model {
	private ArrayList<Double> zero_point = new ArrayList<Double>();
	private ArrayList<Double> limit = new ArrayList<Double>();

	public void set_zp(double a) {
		zero_point.add(a);
	}

	public void set_l(double a) {
		limit.add(a);
	}

	public ArrayList<Double> get_zp() {
		return zero_point;
	}

	public ArrayList<Double> get_l() {
		return limit;
	}
}
