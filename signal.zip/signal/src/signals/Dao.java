package signals;

import java.util.ArrayList;
import java.util.Collections;

/*
 * 控制层
 */
public class Dao {

	public Model split_zero(String s) {
		Model model = new Model();

		if (s.equals("1")) {
			return model;
		}

		String[] a = s.split("\\*");

		for (String string : a) {

			char[] ch = string.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				if (ch[i] == 's' && ((i + 1) < ch.length)) {
					if (ch[i + 1] == '+') {
						int j = i + 1;
						String str = "-";
						while (ch[j + 1] != ')') {
							str = str.concat(String.valueOf(ch[j + 1]));
							j++;
						}

						if (!str.equals("-")) {
							model.set_zp(Double.parseDouble(str));
						}
					} else if (ch[i + 1] == '-') {
						int j = i + 1;
						String str = "";
						while (ch[j + 1] != ')') {
							str = str.concat(String.valueOf(ch[j + 1]));
							j++;
						}
						if (str != null) {
							model.set_zp(Double.parseDouble(str));
						}
					}
				} else if(ch[i] == 's' && ((i + 1) >= ch.length)){
					model.set_zp(0);
				}
			}
		}
		return model;
	}

	public Model split_limit(String s) {
		Model model = new Model();

		String[] a = s.split("\\*");

		for (String string : a) {

			char[] ch = string.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				if (ch[i] == 's') {
					if (ch[i + 1] == '+') {
						int j = i + 1;
						String str = "-";
						while (ch[j + 1] != ')') {
							str = str.concat(String.valueOf(ch[j + 1]));
							j++;
						}

						if (!str.equals("-")) {
							model.set_l(Double.parseDouble(str));
						}
					} else if (ch[i + 1] == '-') {
						int j = i + 1;
						String str = "";
						while (ch[j + 1] != ')') {
							str = str.concat(String.valueOf(ch[j + 1]));
							j++;
						}
						if (str != null) {
							model.set_l(Double.parseDouble(str));
						}
					} else {
						model.set_l(0);
					}
				}
			}
		}
		return model;
	}

public String stable(Model m) {
	ArrayList<Double> limit_point = m.get_l();
	String s = null;
	int ta = 1;
	labe: for (double a : limit_point) {
		while (a > 0) {
			s="H(s)不是稳定系统";
			ta = 0;
			break labe;
		}
	}
	if (ta != 0) {
		s="H(s)是稳定系统";
	}
	
	return s;
}
public String all_pass(Model m1,Model m2) {
	String s = null;
	ArrayList<Double> zero_point = m1.get_zp();
	ArrayList<Double> limit_point = m2.get_l();
	if(zero_point.size()==0) {
		return"H(s)不是全通函数";
	}
	Collections.sort(zero_point);
	Collections.sort(limit_point);
	labe:for(int i = 0;i<limit_point.size();i++) {
		for(int j =zero_point.size()-1;j>=0;j--) {
			if(limit_point.get(i) != (- zero_point.get(j))) {
				s="H(s)不是全通函数";
				break labe;
			}
		}
	}
	if(s==null) {
		s="H(s)是全通函数";
	}
	
	return s;
	}
}
